Login Information

To login as an admin use
username: admin
password: admin

To login as a student user use
username: ATR/3308/09
password: admin